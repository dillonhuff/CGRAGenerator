This is a variable bit-width wallace tree generator and testbench
To run it, use:
  make clean run SIM_ENGINE=mentor

* Replace SIM_ENGINE=mentor with SIM_ENGINE=synopsys for using 
  synopsys simulation tools.

