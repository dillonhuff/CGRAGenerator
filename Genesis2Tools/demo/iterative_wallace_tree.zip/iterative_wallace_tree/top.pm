package top;
use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

use Exporter;
use FileHandle;
use Env; # Make environment variables available


use Genesis2::Manager 1.00;
use Genesis2::UniqueModule 1.00;

@ISA = qw(Exporter Genesis2::UniqueModule);
@EXPORT = qw();
@EXPORT_OK = qw();

$VERSION = '1.0';

############################### Module Starts Here ###########################


  sub to_verilog{ 
      # START PRE-GENERATED TO_VERILOG PREFIX CODE >>>
      my $self = shift;
      local $Genesis2::UniqueModule::myself = $self;
      local $Genesis2::UniqueModule::src_inline;
      local $Genesis2::UniqueModule::src_infile;
      
      print STDERR "$self->{BaseModuleName}->to_verilog: Start user code\n" 
	  if $self->{Debug} & 8;
      # <<< END PRE-GENERATED TO_VERILOG PREFIX CODE

      # START USER CODE PARSED INTO PACKAGE >>> 
$Genesis2::UniqueModule::src_infile = "/home/shacham/ChipGenesis/svn_src/demo/iterative_wallace_tree/genesis-source/top.vp";
$self->SUPER::to_verilog;
print { $self->{OutfileHandle} } '// Top module for simulation // ';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 2;
print { $self->{OutfileHandle} } '';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 3;
print { $self->{OutfileHandle} } '';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 4;
print { $self->{OutfileHandle} } 'module '; print { $self->{OutfileHandle} } mname; print { $self->{OutfileHandle} } ' ();';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 5;
print { $self->{OutfileHandle} } '';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 6;
print { $self->{OutfileHandle} } '   int seed;';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 7;
print { $self->{OutfileHandle} } '   ';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 8;
print { $self->{OutfileHandle} } '   // Generate the wallace tree here';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 9;
    my $wallace = generate('wallace', "my_wallace_inst");
    my $N = $wallace->get_param('N');
print { $self->{OutfileHandle} } '';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 12;
print { $self->{OutfileHandle} } '   // local signals';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 13;
print { $self->{OutfileHandle} } '   logic ['; print { $self->{OutfileHandle} } $N-1; print { $self->{OutfileHandle} } ':0]     multiplier_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ';';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 14;
print { $self->{OutfileHandle} } '   logic ['; print { $self->{OutfileHandle} } $N-1; print { $self->{OutfileHandle} } ':0] 	multiplicand_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ';';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 15;
print { $self->{OutfileHandle} } '   logic ['; print { $self->{OutfileHandle} } $N-1; print { $self->{OutfileHandle} } ':0] 	pp_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } '['; print { $self->{OutfileHandle} } $N-1; print { $self->{OutfileHandle} } ':0];';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 16;
print { $self->{OutfileHandle} } '   logic ['; print { $self->{OutfileHandle} } 2*$N-1; print { $self->{OutfileHandle} } ':0] 	sum_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ';';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 17;
print { $self->{OutfileHandle} } '   logic ['; print { $self->{OutfileHandle} } 2*$N-1; print { $self->{OutfileHandle} } ':0] 	carry_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ';';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 18;
print { $self->{OutfileHandle} } '   logic ['; print { $self->{OutfileHandle} } 2*$N-1; print { $self->{OutfileHandle} } ':0] 	total_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ';';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 19;
print { $self->{OutfileHandle} } '   logic ['; print { $self->{OutfileHandle} } 2*$N-1; print { $self->{OutfileHandle} } ':0] 	expected_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ';';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 20;
print { $self->{OutfileHandle} } '   ';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 21;
print { $self->{OutfileHandle} } '';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 22;
print { $self->{OutfileHandle} } '   assign total_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ' = sum_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ' + carry_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ';';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 23;
print { $self->{OutfileHandle} } '   assign expected_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ' = multiplier_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ' * multiplicand_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ';';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 24;
print { $self->{OutfileHandle} } '';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 25;
print { $self->{OutfileHandle} } '   // Generate partial products';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 26;
      foreach my $i (0..$N-1){
print { $self->{OutfileHandle} } '   assign pp_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } '['; print { $self->{OutfileHandle} } $i; print { $self->{OutfileHandle} } '] = (multiplicand_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } '['; print { $self->{OutfileHandle} } $i; print { $self->{OutfileHandle} } '] == 1\'b1) ? multiplier_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ' : '; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } '\'b0;';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 28;
      } # end of "foreach my $i..."
print { $self->{OutfileHandle} } '';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 30;
print { $self->{OutfileHandle} } '   // Instantiate the wallace tree here';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 31;
print { $self->{OutfileHandle} } '   '; print { $self->{OutfileHandle} } $wallace->instantiate(); print { $self->{OutfileHandle} } ' ';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 32;
print { $self->{OutfileHandle} } '     (.pp(pp_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } '),';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 33;
print { $self->{OutfileHandle} } '      .sum(sum_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } '),';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 34;
print { $self->{OutfileHandle} } '      .carry(carry_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } '));';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 35;
print { $self->{OutfileHandle} } '   ';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 36;
print { $self->{OutfileHandle} } '';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 37;
print { $self->{OutfileHandle} } '   initial begin';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 38;
print { $self->{OutfileHandle} } '      int i;';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 39;
print { $self->{OutfileHandle} } '      #'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ';';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 40;
print { $self->{OutfileHandle} } '      $display("%t: AGENT '; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ' IS ALIVE -- NOW RUN TESTS...", $time);';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 41;
print { $self->{OutfileHandle} } '      for (i=0; i<10; i++) begin';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 42;
print { $self->{OutfileHandle} } '	 multiplier_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ' = $random(seed);';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 43;
print { $self->{OutfileHandle} } '	 multiplicand_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ' = $random(seed);';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 44;
print { $self->{OutfileHandle} } '	 #100;';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 45;
print { $self->{OutfileHandle} } '	 assert (expected_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } '== total_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ')';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 46;
print { $self->{OutfileHandle} } '	   $display("%t: Agent '; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ': Calculating 0x%h * 0x%h -- Expected:0x%h -- Found: 0x%h", ';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 47;
print { $self->{OutfileHandle} } '		    $time,multiplier_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ', multiplicand_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ', expected_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ', total_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ');else';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 48;
print { $self->{OutfileHandle} } '	     $fatal("%t: SVA ERROR  Agent '; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ': Calculating 0x%h * 0x%h -- Expected:0x%h -- Found: 0x%h", ';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 49;
print { $self->{OutfileHandle} } '		    $time,multiplier_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ', multiplicand_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ', expected_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ', total_'; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ');';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 50;
print { $self->{OutfileHandle} } '      end // for (i=0; i<10; i++)';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 51;
print { $self->{OutfileHandle} } '      #100;';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 52;
print { $self->{OutfileHandle} } '      $display("%t: AGENT '; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ' IS DONE", $time);';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 53;
print { $self->{OutfileHandle} } '   end';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 54;
print { $self->{OutfileHandle} } '   ';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 55;
print { $self->{OutfileHandle} } '';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 56;
print { $self->{OutfileHandle} } '   // general intialization procedure';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 57;
print { $self->{OutfileHandle} } '   initial begin';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 58;
print { $self->{OutfileHandle} } '      int dummy;';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 59;
print { $self->{OutfileHandle} } '      // if this is a "+wave" run, it must record all signals';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 60;
print { $self->{OutfileHandle} } '      if ( $test$plusargs("wave") ) ';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 61;
print { $self->{OutfileHandle} } '	begin';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 62;
print { $self->{OutfileHandle} } '           $display("%t: Starting Wave Capture",$time);';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 63;
print { $self->{OutfileHandle} } '           //         levels  instance';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 64;
print { $self->{OutfileHandle} } '           $vcdpluson(0,        top);';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 65;
print { $self->{OutfileHandle} } '	   $vcdplusmemon(0,     top);';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 66;
print { $self->{OutfileHandle} } '        end';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 67;
print { $self->{OutfileHandle} } '      // find the seed for this run';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 68;
print { $self->{OutfileHandle} } '      if ( $test$plusargs("seed") ) ';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 69;
print { $self->{OutfileHandle} } '	begin';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 70;
print { $self->{OutfileHandle} } '	   $value$plusargs("seed=%d", seed);';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 71;
print { $self->{OutfileHandle} } '	end else begin';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 72;
print { $self->{OutfileHandle} } '           seed = 12345;';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 73;
print { $self->{OutfileHandle} } '	end';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 74;
print { $self->{OutfileHandle} } '      $display("%t:\\tUsing seed %d",$time, seed);';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 75;
print { $self->{OutfileHandle} } '      dummy = $random(seed);';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 76;
print { $self->{OutfileHandle} } '   end';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 77;
print { $self->{OutfileHandle} } '   ';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 78;
print { $self->{OutfileHandle} } '   ';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 79;
print { $self->{OutfileHandle} } 'endmodule : '; print { $self->{OutfileHandle} } mname; print { $self->{OutfileHandle} } '';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 80;
      # <<< END OF USER CODE PARSED INTO PACKAGE


      # START PRE-GENERATED TO_VERILOG SUFFIX CODE >>>
      print STDERR "$self->{BaseModuleName}->to_verilog: Done with user code\n" 
	  if $self->{Debug} & 8;

      #
      # clean up code comes here...
      #
      # <<< END PRE-GENERATED TO_VERILOG SUFFIX CODE
  }
