package wallace;
use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

use Exporter;
use FileHandle;
use Env; # Make environment variables available


use Genesis2::Manager 1.00;
use Genesis2::UniqueModule 1.00;

@ISA = qw(Exporter Genesis2::UniqueModule);
@EXPORT = qw();
@EXPORT_OK = qw();

$VERSION = '1.0';

############################### Module Starts Here ###########################


  sub to_verilog{ 
      # START PRE-GENERATED TO_VERILOG PREFIX CODE >>>
      my $self = shift;
      local $Genesis2::UniqueModule::myself = $self;
      local $Genesis2::UniqueModule::src_inline;
      local $Genesis2::UniqueModule::src_infile;
      
      print STDERR "$self->{BaseModuleName}->to_verilog: Start user code\n" 
	  if $self->{Debug} & 8;
      # <<< END PRE-GENERATED TO_VERILOG PREFIX CODE

      # START USER CODE PARSED INTO PACKAGE >>> 
$Genesis2::UniqueModule::src_infile = "/home/shacham/ChipGenesis/svn_src/demo/iterative_wallace_tree/genesis-source/wallace.vp";
$self->SUPER::to_verilog;
# Import Libs
 use POSIX ();

print { $self->{OutfileHandle} } '//  PARAMETERS:';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 5;
 my $N = parameter(name=>'N', val=>4, 
                   doc=>"This is the bit width of the partial products",
                   list=>[1,2,3,4,5,6,7,8,9,16,32,64]);
print { $self->{OutfileHandle} } '';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 9;
print { $self->{OutfileHandle} } '// EXAMPLE: Parameters that are just for demonstration of parameters';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 10;
print { $self->{OutfileHandle} } '//==================================================================';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 11;
 my $forceA=parameter(name=>'forceA', val=>1);
 my $valA=parameter(name=>'valA', val=>15, force=>$forceA);
 $self->error("valA=$valA instead of 15") unless $valA==15;

 my $internal;
 my $cond = parameter(name=>'COND', val=>'false', 
                      doc=>"the value can be true or false",
                       list=>['false','true']);
 if ($cond =~ /true/){
   $internal = parameter(name=>'Internal', val=>4, doc=>'This param only exists if COND==true');
 }
 my $withMin = parameter(name=>'ParWithMin', val=>107, min=>106);
 my $withMax = parameter(name=>'ParWithMax', val=>200, max=>210);
 my $withMinStep = parameter(name=>'ParWithMinStep', val=>309, min=>300, step=>3);
 my $withMaxStep = parameter(name=>'ParWithMaxStep', val=>404, max=>410, step=>2);
 my $withMinMax = parameter(name=>'ParWithMinMax', val=>505, min=>500, max=>510);
 my $withMinMaxStep = parameter(name=>'ParWithMinMaxStep', val=>622, min=>610, max=>630, step=>2);

 my $me = parameter(name=>'ParamExamplePointerToMe', val=>$self);
 my $hsh = parameter(name=>'ParamHash', val=>{Assoc=>4, waySize=>4096, wordSize=>64, lineSize=>256});
 my $you = parameter(name=>'ParamComplexStruct', 
                     val=>['value', [1,2,3,4], {a=>1,b=>2,c=>3,d=>['a','b','c','x']}],
                     doc=>'This is realy a complex type that no one should ever use as parameter');
print { $self->{OutfileHandle} } '//==================================================================';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 35;
print { $self->{OutfileHandle} } '';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 36;
print { $self->{OutfileHandle} } '// Wallace tree for N='; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ' partioal products of width N='; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } ' //';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 37;
print { $self->{OutfileHandle} } 'module '; print { $self->{OutfileHandle} } mname(); print { $self->{OutfileHandle} } ' ';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 38;
print { $self->{OutfileHandle} } '  ( input logic ['; print { $self->{OutfileHandle} } $N-1; print { $self->{OutfileHandle} } ':0] pp['; print { $self->{OutfileHandle} } $N-1; print { $self->{OutfileHandle} } ':0],';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 39;
print { $self->{OutfileHandle} } '    output logic ['; print { $self->{OutfileHandle} } 2*$N-1; print { $self->{OutfileHandle} } ':0] sum,	   ';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 40;
print { $self->{OutfileHandle} } '    output logic ['; print { $self->{OutfileHandle} } 2*$N-1; print { $self->{OutfileHandle} } ':0] carry		   ';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 41;
print { $self->{OutfileHandle} } '   );';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 42;
print { $self->{OutfileHandle} } '';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 43;
    my $hight = $N;
    my $width = 2*$N;  
    my $step = 0;
print { $self->{OutfileHandle} } '   // make pps rectangular (insert 0s!)  ';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 47;
print { $self->{OutfileHandle} } '   logic ['; print { $self->{OutfileHandle} } 2*$N-1; print { $self->{OutfileHandle} } ':0] 	      pp0_step'; print { $self->{OutfileHandle} } $step; print { $self->{OutfileHandle} } ';';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 48;
print { $self->{OutfileHandle} } '   assign pp0_step'; print { $self->{OutfileHandle} } $step; print { $self->{OutfileHandle} } ' = {{('; print { $self->{OutfileHandle} } $N; print { $self->{OutfileHandle} } '){1\'b0}}, pp[0]};';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 49;
    for (my $i=1; $i<$N; $i++) {
print { $self->{OutfileHandle} } '   logic ['; print { $self->{OutfileHandle} } 2*$N-1; print { $self->{OutfileHandle} } ':0] 	      pp'; print { $self->{OutfileHandle} } $i; print { $self->{OutfileHandle} } '_step'; print { $self->{OutfileHandle} } $step; print { $self->{OutfileHandle} } ';';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 51;
print { $self->{OutfileHandle} } '   assign pp'; print { $self->{OutfileHandle} } $i; print { $self->{OutfileHandle} } '_step'; print { $self->{OutfileHandle} } $step; print { $self->{OutfileHandle} } ' = {{('; print { $self->{OutfileHandle} } $N-$i; print { $self->{OutfileHandle} } '){1\'b0}}, pp['; print { $self->{OutfileHandle} } $i; print { $self->{OutfileHandle} } '], {'; print { $self->{OutfileHandle} } $i; print { $self->{OutfileHandle} } '{1\'b0}}};';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 52;
    }
print { $self->{OutfileHandle} } '';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 54;
print { $self->{OutfileHandle} } '';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 55;
    while($hight > 2){
      $step++; $width++;
print { $self->{OutfileHandle} } '   // STARTING TREE REDUCTION STEP '; print { $self->{OutfileHandle} } $step; print { $self->{OutfileHandle} } '';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 58;
print { $self->{OutfileHandle} } '   // Sum:';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 59;
      for (my $i=0; $i < POSIX::floor($hight/3); $i++){
print { $self->{OutfileHandle} } '   logic ['; print { $self->{OutfileHandle} } $width-1; print { $self->{OutfileHandle} } ':0]       pp'; print { $self->{OutfileHandle} } $i; print { $self->{OutfileHandle} } '_step'; print { $self->{OutfileHandle} } $step; print { $self->{OutfileHandle} } ';';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 61;
print { $self->{OutfileHandle} } '   assign pp'; print { $self->{OutfileHandle} } $i; print { $self->{OutfileHandle} } '_step'; print { $self->{OutfileHandle} } $step; print { $self->{OutfileHandle} } ' = {1\'b0, // pad with a zero';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 62;
print { $self->{OutfileHandle} } '				pp'; print { $self->{OutfileHandle} } 3*$i; print { $self->{OutfileHandle} } '_step'; print { $self->{OutfileHandle} } $step-1; print { $self->{OutfileHandle} } ' ^ ';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 63;
print { $self->{OutfileHandle} } '				pp'; print { $self->{OutfileHandle} } 3*$i+1; print { $self->{OutfileHandle} } '_step'; print { $self->{OutfileHandle} } $step-1; print { $self->{OutfileHandle} } ' ^ ';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 64;
print { $self->{OutfileHandle} } '				pp'; print { $self->{OutfileHandle} } 3*$i+2; print { $self->{OutfileHandle} } '_step'; print { $self->{OutfileHandle} } $step-1; print { $self->{OutfileHandle} } '';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 65;
print { $self->{OutfileHandle} } '				};   ';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 66;
      } # end of "for (my $i..."
print { $self->{OutfileHandle} } '';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 68;
print { $self->{OutfileHandle} } '   // Carry:';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 69;
      for (my $i=0; $i < POSIX::floor($hight/3); $i++){
        my $idx = $i + POSIX::floor($hight/3);
print { $self->{OutfileHandle} } '   logic ['; print { $self->{OutfileHandle} } $width-1; print { $self->{OutfileHandle} } ':0] pp'; print { $self->{OutfileHandle} } $idx; print { $self->{OutfileHandle} } '_step'; print { $self->{OutfileHandle} } $step; print { $self->{OutfileHandle} } ';';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 72;
print { $self->{OutfileHandle} } '   assign pp'; print { $self->{OutfileHandle} } $idx; print { $self->{OutfileHandle} } '_step'; print { $self->{OutfileHandle} } $step; print { $self->{OutfileHandle} } ' = {(pp'; print { $self->{OutfileHandle} } 3*$i; print { $self->{OutfileHandle} } '_step'; print { $self->{OutfileHandle} } $step-1; print { $self->{OutfileHandle} } ' & pp'; print { $self->{OutfileHandle} } 3*$i+1; print { $self->{OutfileHandle} } '_step'; print { $self->{OutfileHandle} } $step-1; print { $self->{OutfileHandle} } ') | ';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 73;
print { $self->{OutfileHandle} } '				  (pp'; print { $self->{OutfileHandle} } 3*$i+1; print { $self->{OutfileHandle} } '_step'; print { $self->{OutfileHandle} } $step-1; print { $self->{OutfileHandle} } ' & pp'; print { $self->{OutfileHandle} } 3*$i+2; print { $self->{OutfileHandle} } '_step'; print { $self->{OutfileHandle} } $step-1; print { $self->{OutfileHandle} } ') |';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 74;
print { $self->{OutfileHandle} } '				  (pp'; print { $self->{OutfileHandle} } 3*$i; print { $self->{OutfileHandle} } '_step'; print { $self->{OutfileHandle} } $step-1; print { $self->{OutfileHandle} } ' & pp'; print { $self->{OutfileHandle} } 3*$i+2; print { $self->{OutfileHandle} } '_step'; print { $self->{OutfileHandle} } $step-1; print { $self->{OutfileHandle} } '),';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 75;
print { $self->{OutfileHandle} } '				  1\'b0 // pad with a zero';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 76;
print { $self->{OutfileHandle} } '				  };';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 77;
      } # end of "for (my $i..."   
print { $self->{OutfileHandle} } '   ';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 79;
print { $self->{OutfileHandle} } '   // Left overs:';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 80;
      for (my $i=0; $i < $hight%3; $i++){
        my $old_idx = $i + 3*POSIX::floor($hight/3);
        my $new_idx = $i + 2 * POSIX::floor($hight/3);
print { $self->{OutfileHandle} } '   logic ['; print { $self->{OutfileHandle} } $width-1; print { $self->{OutfileHandle} } ':0] pp'; print { $self->{OutfileHandle} } $new_idx; print { $self->{OutfileHandle} } '_step'; print { $self->{OutfileHandle} } $step; print { $self->{OutfileHandle} } ';';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 84;
print { $self->{OutfileHandle} } '   assign pp'; print { $self->{OutfileHandle} } $new_idx; print { $self->{OutfileHandle} } '_step'; print { $self->{OutfileHandle} } $step; print { $self->{OutfileHandle} } ' = {1\'b0, pp'; print { $self->{OutfileHandle} } $old_idx; print { $self->{OutfileHandle} } '_step'; print { $self->{OutfileHandle} } $step-1; print { $self->{OutfileHandle} } '};';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 85;
      } # end of "for (my $i..."
    $hight = 2 * POSIX::floor($hight/3) + $hight%3;
print { $self->{OutfileHandle} } '   // END TREE REDUCTION STEP '; print { $self->{OutfileHandle} } $step; print { $self->{OutfileHandle} } '';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 88;
print { $self->{OutfileHandle} } '';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 89;
print { $self->{OutfileHandle} } '   ';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 90;
    } # end of "while($hight > 2)..."
print { $self->{OutfileHandle} } '';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 92;
print { $self->{OutfileHandle} } '   // Ignore all the top bits and assign final PPs to output';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 93;
print { $self->{OutfileHandle} } '   assign sum = pp0_step'; print { $self->{OutfileHandle} } $step; print { $self->{OutfileHandle} } '['; print { $self->{OutfileHandle} } 2*$N-1; print { $self->{OutfileHandle} } ':0];';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 94;
print { $self->{OutfileHandle} } '   assign carry = pp1_step'; print { $self->{OutfileHandle} } $step; print { $self->{OutfileHandle} } '['; print { $self->{OutfileHandle} } 2*$N-1; print { $self->{OutfileHandle} } ':0];';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 95;
print { $self->{OutfileHandle} } '   ';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 96;
print { $self->{OutfileHandle} } '   ';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 97;
print { $self->{OutfileHandle} } 'endmodule : '; print { $self->{OutfileHandle} } mname; print { $self->{OutfileHandle} } ' ';print { $self->{OutfileHandle} } "\n";$Genesis2::UniqueModule::src_inline = 98;
      # <<< END OF USER CODE PARSED INTO PACKAGE


      # START PRE-GENERATED TO_VERILOG SUFFIX CODE >>>
      print STDERR "$self->{BaseModuleName}->to_verilog: Done with user code\n" 
	  if $self->{Debug} & 8;

      #
      # clean up code comes here...
      #
      # <<< END PRE-GENERATED TO_VERILOG SUFFIX CODE
  }
