This is a variable bit-width wallace tree generator and testbench
To run it, use:
  make clean run SIM_ENGINE=mentor

* Note that it generates about 9 different wallace trees and tests them all.
* Replace SIM_ENGINE=mentor with SIM_ENGINE=synopsys for using 
  synopsys simulation tools.

